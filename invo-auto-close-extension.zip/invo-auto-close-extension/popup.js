const dot = document.getElementById('dot');
const status = document.getElementById('status');
const toggleBtn = document.getElementById('toggleBtn');
const logBtn = document.getElementById('logBtn');
const logDiv = document.getElementById('log');

function render(enabled) {
  if (enabled) {
    dot.style.background = '#2ee6a6'; dot.style.boxShadow = '0 0 6px #2ee6a6';
    status.textContent = 'ON \u2014 watching app.invoapp.com/wallet for closes.';
    toggleBtn.textContent = 'Turn OFF';
    toggleBtn.style.background = '#ff4d4f'; toggleBtn.style.color = '#fff';
  } else {
    dot.style.background = '#ff4d4f'; dot.style.boxShadow = '0 0 6px #ff4d4f';
    status.textContent = 'OFF \u2014 manual mode. Nothing will auto-close.';
    toggleBtn.textContent = 'Turn ON';
    toggleBtn.style.background = '#2ee6a6'; toggleBtn.style.color = '#111318';
  }
}

function loadState() {
  chrome.storage.local.get(['invoAutoCloseEnabled'], (result) => {
    const enabled = result.invoAutoCloseEnabled !== false;
    render(enabled);
  });
}

toggleBtn.addEventListener('click', () => {
  chrome.storage.local.get(['invoAutoCloseEnabled'], (result) => {
    const current = result.invoAutoCloseEnabled !== false;
    const next = !current;
    chrome.storage.local.set({ invoAutoCloseEnabled: next }, () => render(next));
  });
});

logBtn.addEventListener('click', () => {
  chrome.storage.local.get(['invoAutoCloseAuditLog'], (result) => {
    const entries = result.invoAutoCloseAuditLog || [];
    if (logDiv.style.display === 'none' || !logDiv.style.display) {
      logDiv.style.display = 'block';
      if (entries.length === 0) {
        logDiv.textContent = 'No audit entries yet.';
      } else {
        logDiv.textContent = entries
          .slice(-40)
          .reverse()
          .map((e) => `${e.t.split('T')[1].split('.')[0]}  ${e.event}  ${e.detail}`)
          .join('\n');
      }
    } else {
      logDiv.style.display = 'none';
    }
  });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.invoAutoCloseEnabled) {
    render(changes.invoAutoCloseEnabled.newValue !== false);
  }
});

loadState();
