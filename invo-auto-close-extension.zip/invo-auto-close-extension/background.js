// ============================================================
// BACKGROUND SERVICE WORKER
// ------------------------------------------------------------
// Responsibilities (kept deliberately narrow):
//   1. Ensure exactly one offscreen document exists to host the tick Worker.
//   2. Relay each tick from the offscreen document to whichever tab(s)
//      currently have our content script running on /wallet.
//   3. Own tab navigation for "return to wallet" -- chrome.tabs.update is
//      more reliable across reloads than a content script driving its
//      own location, and it survives the content script being torn down
//      mid-navigation.
//   4. A chrome.alarms heartbeat as a BACKUP only -- if the offscreen
//      document or its worker ever dies unexpectedly, this alarm (every
//      1 minute, MV3's minimum) notices and recreates it. It is not the
//      primary timing source, so the 1-minute granularity limitation of
//      chrome.alarms never affects trade-close reaction time.
// ------------------------------------------------------------
// This file has NO knowledge of Flutter, semantics trees, or trading
// logic. That all lives in content.js. This keeps the MV3-specific
// plumbing isolated from the part of the code that actually matters to
// you and that you'll want explained/changed most often.
// ============================================================

const WALLET_URL_PREFIX = 'https://app.invoapp.com/wallet';
const HEARTBEAT_ALARM_NAME = 'invoAutoClose_offscreenHeartbeat';

let offscreenReady = false;
let creatingOffscreen = null;

async function ensureOffscreenDocument() {
  const existing = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (existing && existing.length > 0) {
    offscreenReady = true;
    return;
  }
  if (creatingOffscreen) {
    await creatingOffscreen;
    return;
  }

  creatingOffscreen = chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['BLOBS'],
    justification: 'Hosts a Worker-based interval timer immune to MV3 service worker suspension, used to poll the Invoapp wallet page for trade closes.'
  }).then(() => {
    offscreenReady = true;
  }).catch((err) => {
    // "Only a single offscreen document may be created" races are expected
    // occasionally when multiple wake-ups overlap -- not fatal.
    console.log('[InvoAutoClose:background] offscreen create note:', err && err.message);
    offscreenReady = true;
  }).finally(() => {
    creatingOffscreen = null;
  });

  await creatingOffscreen;
}

// ------------------------------------------------------------
// Relay ticks from the offscreen document to any wallet tabs.
// ------------------------------------------------------------
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== 'object') return;

  if (message.type === 'OFFSCREEN_TICK') {
    relayTickToWalletTabs(message.tick);
    return;
  }

  if (message.type === 'FORCE_RETURN_TO_WALLET') {
    handleForceReturnToWallet(sender, message.reason);
    return;
  }

  if (message.type === 'CONTENT_SCRIPT_READY') {
    ensureOffscreenDocument();
    return;
  }
});

async function relayTickToWalletTabs(tick) {
  try {
    const tabs = await chrome.tabs.query({ url: `${WALLET_URL_PREFIX}*` });
    for (const tab of tabs) {
      if (tab.id === undefined) continue;
      chrome.tabs.sendMessage(tab.id, { type: 'TICK', tick }).catch(() => {
        // Tab may not have the content script attached yet (e.g. mid-navigation)
        // -- harmless, next tick a moment later will find it.
      });
    }
  } catch (err) {
    console.log('[InvoAutoClose:background] relayTickToWalletTabs error:', err);
  }
}

// ------------------------------------------------------------
// Guaranteed return to wallet, owned by the background worker so it
// survives the content script itself being torn down by the navigation
// it triggers.
// ------------------------------------------------------------
let lastReloadAttempt = 0;
const RELOAD_COOLDOWN_MS = 4000;

async function handleForceReturnToWallet(sender, reason) {
  const now = Date.now();
  if (now - lastReloadAttempt < RELOAD_COOLDOWN_MS) {
    console.log('[InvoAutoClose:background] Reload suppressed (cooldown). Reason was:', reason);
    return;
  }
  lastReloadAttempt = now;

  const tabId = sender && sender.tab && sender.tab.id;
  if (tabId === undefined) return;

  console.log('[InvoAutoClose:background] Forcing return to wallet. Reason:', reason);

  try {
    const tab = await chrome.tabs.get(tabId);
    const currentUrl = (tab.url || '').split('#')[0].split('?')[0];
    if (currentUrl !== WALLET_URL_PREFIX) {
      await chrome.tabs.update(tabId, { url: WALLET_URL_PREFIX });
    } else {
      await chrome.tabs.reload(tabId);
    }
  } catch (err) {
    console.log('[InvoAutoClose:background] handleForceReturnToWallet error:', err);
  }
}

// ------------------------------------------------------------
// Backup heartbeat: chrome.alarms minimum granularity is ~1 minute.
// This is intentionally NOT the trade-close timing path -- it only
// recreates the offscreen document if it was unexpectedly torn down.
// ------------------------------------------------------------
chrome.alarms.create(HEARTBEAT_ALARM_NAME, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === HEARTBEAT_ALARM_NAME) ensureOffscreenDocument();
});

chrome.runtime.onStartup.addListener(() => ensureOffscreenDocument());
chrome.runtime.onInstalled.addListener(() => ensureOffscreenDocument());

// Kick off immediately on service worker load too (covers the case where
// the SW was woken by a message rather than browser startup/install).
ensureOffscreenDocument();
