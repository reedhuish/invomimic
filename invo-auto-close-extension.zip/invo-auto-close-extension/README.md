# Invoapp Wallet Auto Close (Chrome Extension, v2.3 logic)

Automates the "Close Position -> Confirm" flow on `https://app.invoapp.com/wallet`,
verifies the trade actually left the list, and guarantees a return to the wallet
page afterward. This is a direct port of the Tampermonkey userscript's v2.3
trading logic into a Manifest V3 Chrome extension.

## Option A: Load unpacked (free, fastest to set up)

1. Unzip this folder somewhere permanent (don't delete it after -- Chrome loads
   the extension live from this folder every time it starts).
2. Open `chrome://extensions` in Chrome.
3. Toggle **Developer mode** on (top-right switch).
4. Click **Load unpacked**.
5. Select this folder (the one containing `manifest.json`).
6. The extension icon should appear in the toolbar. Pin it for easy access.
7. Navigate to `https://app.invoapp.com/wallet` and log in as usual.
8. Click the toolbar icon to confirm it says **ON**.

Chrome may show a "Disable developer mode extensions" banner on some builds --
this is expected for unpacked extensions and does not stop it from working.
If it's ever dismissed, just re-enable it at `chrome://extensions`.

## Option B: Pack into a .crx for manual distribution

1. At `chrome://extensions` with Developer mode on, click **Pack extension**.
2. Point "Extension root directory" at this folder.
3. Leave "Private key file" blank the first time -- Chrome will generate one
   (`invo-auto-close-extension.pem`). **Keep that .pem file safe** -- you need
   the same one to publish updates later without users having to reinstall.
4. Chrome produces a `.crx` file. Chrome will refuse to install a `.crx` by
   drag-and-drop for security reasons in current versions -- the practical
   path for a small private distribution is still Option A (unpacked) unless
   you go through the Chrome Web Store (private/unlisted listing), which
   handles signing and installation for you.

## What's different from the Tampermonkey userscript

- **Timing engine** moved from an in-page Worker to an offscreen document's
  Worker, coordinated by a background service worker. This is required
  because Manifest V3 background scripts are non-persistent and can be
  killed by Chrome at any time -- the offscreen document keeps the same
  sub-second polling behavior alive reliably. See comments in
  `background.js` and `offscreen.js`.
- **On/off state and audit log** moved from `localStorage` to
  `chrome.storage.local`, so the toolbar popup and the in-page status panel
  both read/write the same state.
- **Page navigation** ("return to wallet") is requested from the content
  script but performed by the background service worker via `chrome.tabs`,
  which is more reliable across the exact reload it triggers.
- All Flutter/DOM-reading logic, the close -> confirm sequence, the
  fail-closed modal-scoped Confirm matching, and the post-close verification
  step are unchanged from userscript v2.3.

## Files

| File | Purpose |
|---|---|
| `manifest.json` | Extension configuration (MV3) |
| `content.js` | All trading logic -- runs on the wallet page |
| `background.js` | Service worker -- manages offscreen doc, tab navigation |
| `offscreen.js` / `offscreen.html` | Hosts the tick Worker, immune to MV3 suspension |
| `popup.html` / `popup.js` | Toolbar on/off toggle and audit log viewer |
| `icons/` | Placeholder icons (solid teal) -- replace with your own if desired |

## Known limitation carried over from the userscript

The circuit breaker (pauses after 3 consecutive close/confirm failures) still
resumes with identical logic after its backoff window -- it does not diagnose
*why* the failures happened. If you see repeated circuit-breaker trips, that's
worth a targeted follow-up rather than assuming this build fixed it.
