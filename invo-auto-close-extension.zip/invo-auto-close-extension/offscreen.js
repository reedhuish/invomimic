// ============================================================
// OFFSCREEN TIMER HOST
// ------------------------------------------------------------
// This is the MV3-safe home for the sub-second tick engine that used
// to live directly in the Tampermonkey userscript's page context.
//
// Why this exists: MV3 background service workers are non-persistent --
// Chrome can suspend them after ~30s of inactivity, so a naive
// setInterval() in background.js is not reliable for sub-second polling.
// Offscreen documents are a full DOM/JS context that Chrome keeps alive
// as long as we hold a reason for it open, so a Worker here behaves the
// same way it did inside the old userscript's tab.
//
// This file only produces ticks. It has no knowledge of Invoapp, DOM
// selectors, or trading logic -- all of that stays in content.js, which
// is the only piece with access to the actual wallet page DOM.
// ============================================================

const workerCode = `
  let intervalIds = {};
  self.onmessage = function(e) {
    const { cmd, name, ms } = e.data;
    if (cmd === 'start') {
      if (intervalIds[name]) clearInterval(intervalIds[name]);
      intervalIds[name] = setInterval(() => { self.postMessage({ tick: name }); }, ms);
    } else if (cmd === 'stop') {
      if (intervalIds[name]) { clearInterval(intervalIds[name]); delete intervalIds[name]; }
    }
  };
`;

const POLL_INTERVAL_MS = 2000;
const IDLE_CHECK_INTERVAL_MS = 1000;
const URL_WATCHDOG_INTERVAL_MS = 500;
const STUCK_FLAG_WATCHDOG_MS = 5000;
const STATUS_PULSE_MS = 700;
const SESSION_CHECK_MS = 3000;

let worker = null;

function startWorker() {
  const blob = new Blob([workerCode], { type: 'application/javascript' });
  const url = URL.createObjectURL(blob);
  worker = new Worker(url);
  URL.revokeObjectURL(url);

  worker.onmessage = (e) => {
    const tick = e.data && e.data.tick;
    if (!tick) return;
    // Relay every tick to the background service worker. background.js
    // decides which tabs (if any) currently need this tick and forwards
    // it to the right content script via chrome.tabs.sendMessage.
    chrome.runtime.sendMessage({ type: 'OFFSCREEN_TICK', tick }).catch(() => {
      // background may be momentarily asleep between wakeups -- harmless,
      // the next tick a few hundred ms later will get through.
    });
  };

  worker.postMessage({ cmd: 'start', name: 'scanPoll', ms: POLL_INTERVAL_MS });
  worker.postMessage({ cmd: 'start', name: 'idleReload', ms: IDLE_CHECK_INTERVAL_MS });
  worker.postMessage({ cmd: 'start', name: 'urlWatchdog', ms: URL_WATCHDOG_INTERVAL_MS });
  worker.postMessage({ cmd: 'start', name: 'stuckFlagWatchdog', ms: STUCK_FLAG_WATCHDOG_MS });
  worker.postMessage({ cmd: 'start', name: 'statusPulse', ms: STATUS_PULSE_MS });
  worker.postMessage({ cmd: 'start', name: 'sessionCheck', ms: SESSION_CHECK_MS });

  console.log('[InvoAutoClose:offscreen] Tick worker started.');
}

startWorker();
